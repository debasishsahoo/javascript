function OnlyLog() {

}
function OnlyInfo() {

}
function OnlyError() {

}
function OnlyWarning() {

}
function OnlyTable() {

}
function Only404() {

}